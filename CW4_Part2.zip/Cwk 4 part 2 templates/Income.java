public class Income {
    // Create a constructor to initialize Income's objects.
    // and create a list of methods to retrieve and get Income's information.
    // Income  usually contains the following type of information:

    /*
    *
* Base Employment Income
* Overtime
* Bonuses
* Commissions
* Dividends/Interest
* Net Rental Income
* Other
*/
}
