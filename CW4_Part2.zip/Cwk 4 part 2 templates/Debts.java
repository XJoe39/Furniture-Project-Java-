public class Debts {
   // create a constructor to initialize debts's objects.
   // and a list of methods to get and retrieve debts' information.
   // Debts usually have the following type of information


    /*
   • Current mortgage
   • Liens
   • Alimony
   • Child support
   • Car loans
   • Credit cards
   * Real Estate Taxes
   * Homeowner Assn. Dues
   * Hazard Insurance

    *
    * */
}
