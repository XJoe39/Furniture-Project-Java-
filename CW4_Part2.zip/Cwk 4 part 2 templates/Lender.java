public class Lender {
    // create a constructor to initialize Lender's objects.
    // and a list of methods to get and retrieve Lender' information.
    // Lender usually have the following type of information

    /*
* Lender Number
* Debt-to-income (DTI) ratio
* Down payment requirement
* Interest rate
* Lender fees
* Closing costs
* */
}
