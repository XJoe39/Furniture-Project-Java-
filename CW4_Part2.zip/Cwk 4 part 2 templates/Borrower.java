public class Borrower {
    // create a constructor to initialize Borrower's objects.
    // and a list of methods to get and retrieve Borrower' information.
    // Borrower usually have the following type of information

    /*
    * Borrower's Name
    * Social Security Number (SSN)
    * Home Phone
    * DOB (mm/dd/yyyy)
    * Employment
    * Income
    * Assets
    * Debts
    * Credit history
    * */

}
