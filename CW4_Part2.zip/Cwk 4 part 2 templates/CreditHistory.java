public class CreditHistory {
    // Create a constructor to initialize credithistory' objects.
    // Create a list of methods to get and retrieve credithistory' informtion.
    // Credithistory usually has the following type of information:
    /*
   • Bankruptcies
   • Collections
   • Foreclosures
   • Delinquencies
    * */

}
