public class Employment {
    // Create a constructor to initialize Employment objects.
    // and create a list of methods to get and retrieve the Employment's information.
    // Information about the Employment usually contains the following:
    /*
   • Name of current employer, phone, and street address
   • Length of time at current employer
   • Position/title
   • Salary including overtime, bonuses, or commissions
    * */
}
