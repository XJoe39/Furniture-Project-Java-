public class Property {

   // create a constructor to construct property objects,
    // and a list of methods to get and retrieve the property's information
    //
   //   Properties usually have the following type of information:
   /*
   • Street address
   • Expected sales price
   • Type of home (single-family residence, condo, etc.)
   • Size of property
   • Real estate taxes (annual)
   • Homeowner’s association dues (HOA)
    */
}
