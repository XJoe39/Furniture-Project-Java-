public class ClosedApplication extends ProcessedApplication{
    // create a constructor to initialize ClosedApplication's objects.
    // and a list of methods to get and retrieve ClosedApplication' information.
    // Including all information about ProcessedApplication,
    // ClosedApplication usually have the following type of information

/*
*
*  ClosingDisclosure
* */

// define a method to create a closing disclosure

}
