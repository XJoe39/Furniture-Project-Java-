public class Application {
    // create a constructor to initialize Application's objects.
    // and a list of methods to get and retrieve Application' information.
    // Application usually have the following type of information
//

    /*
* Application Number
* Borrower
* Lender
* Property
* Total Assets
* Total Liabilities
     * */

    // Define methods to calculate total assets and total liabilities
    // based on the information of borrower's assets and debts


}
